package com.example.wangpengfei2.activity;

import android.os.Bundle;

import com.example.wangpengfei2.BaseActivity;
import com.example.wangpengfei2.R;

public class PersonCentrActivity extends BaseActivity {

	@Override
	protected void onCreate(Bundle arg0) {

		super.onCreate(arg0);
		this.setContentView(R.layout.layout_person_center);
		
	}

}
