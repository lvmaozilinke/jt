package com.example.wangpengfei2.bean;

public class LeftMenuLvBean {
//���ñ����б����ͼƬ�����֣�
	private String mItemTv;
	private int mItemImg;
	
	public String getmItemTv() {
		return mItemTv;
	}
	public void setmItemTv(String mItemTv) {
		this.mItemTv = mItemTv;
	}
	public int getmItemImg() {
		return mItemImg;
	}
	public void setmItemImg(int mItemImg) {
		this.mItemImg = mItemImg;
	}
	
}
